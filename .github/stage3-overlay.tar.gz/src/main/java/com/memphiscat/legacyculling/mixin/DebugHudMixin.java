package com.memphiscat.legacyculling.mixin;

import com.memphiscat.legacyculling.LegacyCullingMod;
import com.memphiscat.legacyculling.compat.OptiFineCompat;
import com.memphiscat.legacyculling.performance.AdaptiveRenderQueue;
import com.memphiscat.legacyculling.renderer.NativeRendererCoordinator;
import com.memphiscat.legacyculling.visibility.CullingStats;
import com.memphiscat.legacyculling.visibility.GpuVisibilityPipeline;
import net.minecraft.client.gui.hud.DebugHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(DebugHud.class)
public abstract class DebugHudMixin {
    @Inject(method = "getRightText", at = @At("RETURN"))
    private void legacyculling$appendStatistics(CallbackInfoReturnable<List<String>> cir) {
        if (!LegacyCullingMod.CONFIG.enabled || !LegacyCullingMod.CONFIG.showStatistics) return;
        CullingStats.Snapshot stats = CullingStats.snapshot();
        List<String> lines = cir.getReturnValue();
        lines.add("");
        lines.add("[Legacy Culling 0.4.0 Stage 3] ACTIVE");
        lines.add("Backend: " + (NativeRendererCoordinator.nativeEnabled() ? "Native" : "Compatibility"));
        lines.add("GPU visibility: " + GpuVisibilityPipeline.status());
        lines.add("Culled E:" + stats.entities + " BE:" + stats.blockEntities + " P:" + stats.particles);
        lines.add("Limits P:" + stats.particleLimit + " Leaf:" + stats.leafFaces + " Sign:" + stats.signText);
        lines.add("Ray:" + stats.rayTests + " CPU HZB:" + stats.hzbHits + "/" + stats.hzbCaptures);
        lines.add("GPU HZB:" + stats.gpuCaptures + " Obj:" + stats.gpuObjectCandidates
                + " Terrain:" + stats.gpuTerrainCandidates);
        lines.add("Draws multi:" + stats.multiDraws + " indirect:" + stats.indirectDraws);
        lines.add("LOD pressure:" + AdaptiveRenderQueue.pressure() + " skips:" + stats.lodSkips);
        lines.add("Hide delay:" + LegacyCullingMod.CONFIG.occlusionHideFrames + " frames");
        lines.add("Chunk submissions:" + stats.chunkUpdates);
        if (NativeRendererCoordinator.emergencyDisabled()) {
            lines.add("Emergency fallback active");
        } else {
            lines.add("Emergency fallback: Ctrl+Shift+F8");
        }
        if (NativeRendererCoordinator.terrainFailed()) {
            lines.add("Terrain fallback: " + NativeRendererCoordinator.terrainFailureReason());
        }
        if (OptiFineCompat.shadersActive()) {
            lines.add("OptiFine shaders: native/GPU paths paused");
        }
    }
}
